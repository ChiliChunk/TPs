#include <stdio.h>
#include <stdlib.h>

int main (){
	int MAX;
	int saisie;
	int i;
	int * tabEntier;
	printf ("Quelle taille de tab\n");
	scanf("%d" , &MAX);
	tabEntier = malloc (sizeof(int)*MAX);
	printf("Saisissez le tab\n");
	for (i = 0 ; i < MAX ; i++){
		scanf("%d" , &saisie);
		tabEntier[i] = saisie;
	}
	
	printf("Affichage du tableau\n");
	for (i=0 ; i < MAX ; i++){
		printf("%d ",tabEntier[i]);
	}
	printf ("\nA l'envers\n");
	for (i=MAX-1 ; i >= 0 ; i--){
		printf("%d ",tabEntier[i]);
	}

	return 0;
		
}
