#include <stdio.h>
#include <stdlib.h>

void say_hello(){
	printf("Bonjour !\n ");
}
