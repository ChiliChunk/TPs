#include <stdio.h>
#include <stdlib.h>
#include "p1.h"

int main(){
	say_hello();
	exit(0);


}
