Bonjour, je suis en groupe avec Guilhem susa qui a rendu le tp a temps. Je ne sais pas si le deux partie du binome doivent rendre le tp mais dans le doute je le rend aussi.
