package exo_02_01;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import java.awt.event.*;



public class FenetreSimple extends JFrame {

	static final int HAUTEUR = 150;
	static final int LARGEUR = 300;

	public FenetreSimple( String titre ) {
		super();
		

		this.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
		this.setTitle(titre);
		this.setSize(LARGEUR,HAUTEUR);
		this.addWindowListener(
				  new WindowAdapter(){
				    public void windowClosing(WindowEvent e) {
					    int bouton = JOptionPane.showConfirmDialog(FenetreSimple.this , "Vraiment Fermer?" , "Confirmation fermeture" , JOptionPane.YES_NO_OPTION );
					    if (bouton == JOptionPane.YES_OPTION){
					    	System.exit(0);
					    }
					    else if (bouton == JOptionPane.NO_OPTION){
					    	System.out.println("ok");
					    }
				    }
				  });	
	}
	
	public static void main (String [] args){
		FenetreSimple fenetre = new FenetreSimple("Une fenetre simple");
		fenetre.setVisible(true);
	}

}
