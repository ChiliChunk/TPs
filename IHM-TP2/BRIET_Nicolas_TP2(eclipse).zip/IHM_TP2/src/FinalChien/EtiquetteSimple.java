package FinalChien;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JLabel;

public class EtiquetteSimple extends JLabel {
	
	public EtiquetteSimple (String texte){
		super();
		this.setText(texte);
	}
	public EtiquetteSimple (ImageIcon image){
		super(image);
	}
	public EtiquetteSimple (String texte , ImageIcon img){
		super(texte , img , JLabel.CENTER);
		this.setIconTextGap(20);
		this.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
	}


}
