package FinalChien;

import java.awt.BorderLayout;

import javax.swing.ImageIcon;

public class WhoLetsTheDogOut {
	public static void main (String [] args){
		FenetreSimple fenetre = new FenetreSimple("titre cool");
		ImageIcon img;
		EtiquetteSimple labelEti = new EtiquetteSimple("Chien", img = new ImageIcon("RESGRAF/Chien.gif"));
		ControleEtiquette CE = new ControleEtiquette(labelEti);
		fenetre.add(CE , BorderLayout.NORTH);
		fenetre.add(labelEti , BorderLayout.SOUTH);
		fenetre.pack();
		fenetre.setVisible(true);
	}
}
