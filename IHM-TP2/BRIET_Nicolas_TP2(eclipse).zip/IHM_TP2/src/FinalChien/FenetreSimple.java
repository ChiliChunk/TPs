package FinalChien;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import java.awt.event.*;


public class FenetreSimple extends JFrame {
	 
	public FenetreSimple( String titre ) {
		super();
		int HAUTEUR = 150;
		int LARGEUR = 300;

		this.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
		this.setTitle(titre);
		//this.setSize();
		this.addWindowListener(
				  new WindowAdapter(){
				    public void windowClosing(WindowEvent e) {
					    int bouton = JOptionPane.showConfirmDialog(FenetreSimple.this , "Vraiment Fermer?" , "Confirmation fermeture" , JOptionPane.YES_NO_OPTION );
					    if (bouton == JOptionPane.YES_OPTION){
					    	System.exit(0);
					    }
					    
				    }
				  });
	}
	
}
