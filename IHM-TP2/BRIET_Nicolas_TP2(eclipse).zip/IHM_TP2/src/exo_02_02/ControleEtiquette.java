package exo_02_02;

import java.awt.BorderLayout;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.JToolBar;
import java.awt.event.*;

public class ControleEtiquette extends JToolBar{
	
	private ImageIcon [] iconesBoutons = new ImageIcon[18];
	private JRadioButton[] boutons = new JRadioButton[6];
	private String nomsIcones[] = { "bhgauche", "bhcentre", "bhdroite","bvhaut",   "bvcentre", "bvbas" };
	private final int positions[] = { JLabel.LEFT, JLabel.CENTER, JLabel.RIGHT,    // horizontales
            							JLabel.TOP,  JLabel.CENTER, JLabel.BOTTOM }; // verticales
	private JLabel leLabel;
	
	
	public ControleEtiquette(JLabel etiquette) {
		super();
		this.leLabel = etiquette;
		this.chargerIcones();
		this.creerBoutons();
		for (int i = 0 ; i < 3 ; i++){
			this.add(boutons[i]);
		}
		this.addSeparator();
		for (int i = 0 ; i < 3 ; i++){
			this.add(boutons[i+3]);
		}
	}
	
	private void chargerIcones(){
		
		String dossier = "RESGRAF/";
		ImageIcon image ;
		String suffixe = "";
		String extension = ".gif";
			
		//image blanche
			for (int i = 0 ; i < 6 ; i++){
				image = new ImageIcon(dossier + nomsIcones[i] + suffixe + extension);
				iconesBoutons[i] = image;
			}
		//image  rouge
			suffixe = "R";
			for (int i = 0 ; i < 6 ; i++){
				image = new ImageIcon(dossier + nomsIcones[i] + suffixe + extension);
				iconesBoutons[i+6] = image;
			}
		//image bleu
			suffixe = "B";
			for (int i = 0 ; i < 6 ; i++){
				image =  new ImageIcon (dossier + nomsIcones[i] + suffixe + extension);
				iconesBoutons[i+12] = image;
			}
			
		
	}
	private void creerBoutons(){
		ButtonGroup BG1 = new ButtonGroup();
		ButtonGroup BG2 = new ButtonGroup();
		String dossier = "RESGRAF/";
		ImageIcon image ;
		JRadioButton Rbutton;
		String suffixe = "";
		String extension = ".gif";
			
		//radio non selectionné
		for (int i = 0 ; i < 6 ; i++){
			image = new ImageIcon(dossier + nomsIcones[i] + suffixe + extension);
			Rbutton = new JRadioButton(image , false );
			boutons[i] = Rbutton;
			//verticaux
			if ( i <= 2 ){
				BG1.add(boutons[i]);
				EcouteurHorizontal ecoutH = new EcouteurHorizontal(positions[i]);
				boutons[i].addActionListener(ecoutH);

			}
			//horizontaux
			else {
				BG2.add(boutons[i]);
				EcouteurVertical ecoutV = new EcouteurVertical(positions[i]);
				boutons[i].addActionListener(ecoutV);
			}
		}
		//radio selectionné
		suffixe = "R";
		for (int i = 0 ; i < 6 ; i++){
			image = new ImageIcon(dossier + nomsIcones[i] + suffixe + extension);
			boutons[i].setSelectedIcon(image);
		}
		
		
		//radio moseover
		suffixe = "B";
		for (int i = 0 ; i < 6 ; i++){
			image = new ImageIcon(dossier + nomsIcones[i] + suffixe + extension);
			boutons[i].setRolloverIcon(image);
		}
		
	}
	
	
	class EcouteurHorizontal implements java.awt.event.ActionListener {
        private int position;

        EcouteurHorizontal(int position) {
            this.position = position;
        }

        public void actionPerformed(ActionEvent evt) {
            leLabel.setHorizontalTextPosition(position);
        }
    }
	
	class EcouteurVertical implements java.awt.event.ActionListener {
        private int position;

        EcouteurVertical(int position) {
            this.position = position;
        }

        public void actionPerformed(ActionEvent evt) {
            leLabel.setVerticalTextPosition(position);
            
        }
    }
	
	
	
	public static void main (String [] args){
		FenetreSimple fenetre = new FenetreSimple("titre cool");
		ImageIcon img;
		EtiquetteSimple labelEti = new EtiquetteSimple("Chien", img = new ImageIcon("RESGRAF/Chien.gif"));
		ControleEtiquette CE = new ControleEtiquette(labelEti);
		fenetre.add(CE , BorderLayout.NORTH);
		fenetre.add(labelEti , BorderLayout.SOUTH);
		fenetre.pack();
		fenetre.setVisible(true);
	}
}
