package exo_02_02;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JLabel;

public class EtiquetteSimple extends JLabel {
	
	public EtiquetteSimple (String texte){
		super();
		this.setText(texte);
	}
	public EtiquetteSimple (ImageIcon image){
		super(image);
	}
	public EtiquetteSimple (String texte , ImageIcon img){
		super(texte , img , JLabel.CENTER);
		this.setIconTextGap(20);
		this.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
	}
	public static void main(String [] args){
		FenetreSimple fenetre = new FenetreSimple("Une fenêtre avec un chien");
		ImageIcon img = new ImageIcon("RESGRAF/Chien.gif");
		EtiquetteSimple etiquette = new EtiquetteSimple("Un chien" ,img);
		etiquette.setHorizontalTextPosition(JLabel.CENTER);
		fenetre.add(etiquette);
		fenetre.pack();
		fenetre.setVisible(true);
	
	}

}
