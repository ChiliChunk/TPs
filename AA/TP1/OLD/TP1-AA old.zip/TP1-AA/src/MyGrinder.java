/* Nicolas BRIET
 * Guilhem SUSA
 * IUT Blagnac
 * Groupe 3A
 */
import java.util.ArrayList;
import java.util.Collection;

import stone.Grinder;
import stone.Stone;


public class MyGrinder implements Grinder{
	
	//int aCasser;

	public static void main(String[] args) {
		Stone cailloux = Stone.makeBigStone();

	}

	@Override
	public Collection<Stone> grind(Stone pierre, int diametre) {
		ArrayList<Stone> alCailloux= new ArrayList<Stone>();
		alCailloux.add(pierre);
		while (tousCasse( alCailloux, diametre) == false){
			;
			//alCailloux.add(alCailloux.get(aCasser).split());
			
			alCailloux.add(pierre.split());
		}
		
		

		return alCailloux;
	}
	public boolean tousCasse (ArrayList<Stone> tabCailloux , int diametre){
		for (int i = 0 ; i < tabCailloux.size() ; i++){
			if (tabCailloux.get(i).diameter() > diametre){
				//this.aCasser=i;
				return false;
			}
		}
		return true;
	}

}
