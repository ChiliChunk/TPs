package expr;

/**
 * Interface for all the arithmetic expressions.
 */
public abstract class Expression {

	/**
	 * Convert the expression into string.
	 * 
	 * @param isSub
	 *            Set to true if the expression is a sub-expression.
	 * @return The text corresponding to the expression
	 */
	public abstract String toString(boolean isSub);
	
	@Override
	public String toString() {
		return toString(false);
	}
}
