package expr;

import java.util.Arrays;
import java.util.List;

/**
 * Binary arithmetic operators. Examples: +, -, *.
 */
public class Operator {
	/**
	 * The symbol of the operator
	 */
	public final String symbol;

	/**
	 * The list of all valid symbols
	 */
	public static final List<String> valid = Arrays.asList("+","*","-","/");

	/**
	 * Construct an operator using its textual representation.
	 * 
	 * @param symbol
	 *            A valid operator symbol
	 */
	public Operator(String symbol) {
		if (symbol == null)
			throw new NullPointerException();
		if (!valid.contains(symbol))
			throw new IllegalArgumentException(symbol);
		this.symbol = symbol;
	}

	@Override
	public String toString() {
		return symbol;
	}

	/**
	 * Tells if the operator is associative. For example, + is associative,
	 * since (a+b)+c = a+(b+c).
	 * 
	 * @return true if the operator is associative.
	 */
	public boolean isAssociative() {
		switch (symbol) {
		case "+":
		case "*":
			return true;
		case "-":
		case "/":
			return false;
		default:
			throw new RuntimeException("No associativity for " + symbol);
		}
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((symbol == null) ? 0 : symbol.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Operator other = (Operator) obj;
		if (symbol == null) {
			if (other.symbol != null)
				return false;
		} else if (!symbol.equals(other.symbol))
			return false;
		return true;
	}
}
