
//TODO afficher le 1 dans la trace apres characters (fin de l'exo 3


import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.SAXException;

import expr.xml.ExprHandler;
import expr.xml.LogHandler;

public class RunParser {

	public static void main(String[] args) throws SAXException, IOException, ParserConfigurationException {
		
		SAXParserFactory usineSax = SAXParserFactory.newInstance();
		usineSax.setValidating(true);
		SAXParser parserSax = usineSax.newSAXParser();
		ExprHandler handler = new ExprHandler();
		parserSax.parse("decoupage2.xml", handler);		
		System.out.println("\n---Parsing fini---");
		
	}

}
