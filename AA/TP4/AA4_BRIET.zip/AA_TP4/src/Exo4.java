import expr.BinaryOperation;
import expr.Constant;
import expr.Expression;
import expr.Operator;
import expr.Variable;

public class Exo4 {
	public static void main (String [] args){
		
		Variable a = new Variable('a');
		Constant one = new Constant(1);
		Operator minus = new Operator("-");
		BinaryOperation binop1 = new BinaryOperation(minus, a, one);
		
		Constant two = 	new Constant(2);
		Operator divis  = new Operator("/");
		
		Expression exprTotal = new BinaryOperation(divis, binop1, two);
		
		System.out.println(exprTotal);
	}
}
