package expr.xml;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.helpers.DefaultHandler;

public class LogHandler extends DefaultHandler {

	@Override
	public void characters(char[] ch, int start, int length) throws SAXException {
		System.out.print("characters ");
		for (int i = start ; i < length+start ; i++){
			System.out.print(ch[i]);
		}
		
		System.out.println();
	}

	@Override
	public void endDocument() throws SAXException {
		System.out.print("endDocument");
	}

	@Override
	public void endElement(String uri, String localName, String qName) throws SAXException {
		System.out.println("endElement: "+qName);
	}

	@Override
	public void startDocument() throws SAXException {
		System.out.println("startDocument");
	}

	@Override
	public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
		System.out.println("startElement: "+qName);
		for (int i = 0 ; i < attributes.getLength() ; i++){
			System.out.print(attributes.getQName(i)+ " : ");
			System.out.println(attributes.getValue(i));
		}
		
	}

	@Override
	public void error(SAXParseException e) throws SAXException {
		throw e;
	}
	
}
