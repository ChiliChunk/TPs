package expr.xml;

import java.util.ArrayDeque;
import java.util.Deque;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import expr.BinaryOperation;
import expr.Constant;
import expr.Expression;
import expr.Operator;
import expr.Variable;

public class ExprHandler extends DefaultHandler{
	
	Deque <Operator> dqOperator = new ArrayDeque<Operator>(); //div add sub mul
	Deque <Expression> dqExpression = new ArrayDeque<Expression>();
	@Override
	public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {

		if (qName.equals("binop") || qName.equals("manyop")){
			
			switch (attributes.getValue(0)){
				case  "sub" :
					dqOperator.push(new Operator("-"));
				break;
				case "add":
					dqOperator.push(new Operator("+"));
				break;
				case "mul":
					dqOperator.push(new Operator("*"));
				break;
				case "div":
					dqOperator.push(new Operator("/"));
				break;
			}
			
		}
		else if (qName.equals("variable")){
			dqExpression.push(new Variable(attributes.getValue(0).charAt(0)));
		}
		
	}
	
	@Override
	public void characters(char[] ch, int start, int length) throws SAXException {
		for (int i = start ; i < start + length ; i++){
			dqExpression.push(new Constant(ch[i]));
		}
	}
	
	@Override
	public void endElement(String uri, String localName, String qName) throws SAXException {
		if (qName.equals("manyop") || qName.equals("binop")){
			Expression exprRight = dqExpression.removeFirst();
			Expression exprLeft = dqExpression.removeFirst();
			Operator op = dqOperator.removeFirst();
			Expression exprTotal = new BinaryOperation(op, exprLeft, exprRight);
			
			dqExpression.push(exprTotal);
		}
	}

	@Override
	public void endDocument() throws SAXException {
		
		System.out.println(dqExpression);
	}
	
	
}
