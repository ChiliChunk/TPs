package expr;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

/**
 * Arithmetic operations with many operands. Example: x+y+z.
 */
public class ManyOperation extends Expression {
	/**
	 * The operator. Must be associative (eg. +, *).
	 */
	protected final Operator op;
	/**
	 * The list of expressions to combine together.
	 */
	protected final List<Expression> operands;

	/**
	 * Constructs an binary operation by combining a list of expressions using
	 * the provided operator.
	 * 
	 * @param op
	 *            The operator
	 * @param operands
	 *            The list of expressions to combine
	 */
	public ManyOperation(Operator op, List<Expression> operands) {
		if (op == null || operands == null)
			throw new NullPointerException();
		if (!op.isAssociative())
			throw new IllegalArgumentException(op.toString()
					+ " is not associative");
		if (operands.isEmpty())
			throw new IllegalArgumentException();
		this.op = op;
		this.operands = operands;
	}

	/**
	 * Constructs an binary operation by combining several expressions using the
	 * provided operator.
	 * 
	 * @param op
	 *            The operator
	 * @param operands
	 *            The expressions to combine
	 */
	public ManyOperation(Operator op, Expression... operands) {
		this(op,Arrays.asList(operands));
	}

	@Override
	public String toString(boolean isSub) {
		Iterator<Expression> it = operands.iterator();
		String content = it.next().toString(true);
		while (it.hasNext())
			content += op + it.next().toString(true);
		if (isSub)
			return "(" + content + ")";
		else
			return content;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((op == null) ? 0 : op.hashCode());
		result = prime * result
				+ ((operands == null) ? 0 : operands.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ManyOperation other = (ManyOperation) obj;
		if (op == null) {
			if (other.op != null)
				return false;
		} else if (!op.equals(other.op))
			return false;
		if (operands == null) {
			if (other.operands != null)
				return false;
		} else if (!operands.equals(other.operands))
			return false;
		return true;
	}

}
